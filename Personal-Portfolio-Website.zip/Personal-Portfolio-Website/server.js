const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static('public'));

// Main route for the home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/projects/project-1', (req, res) => {
    res.send('<h1>Project 1</h1><p>Details about Project 1 will be added soon!</p>');
});

app.get('/projects/project-2', (req, res) => {
    res.send('<h1>Project 2</h1><p>Details about Project 2 will be added soon!</p>');
});

app.get('/projects/project-3', (req, res) => {
    res.send('<h1>Project 3</h1><p>Details about Project 3 will be added soon!</p>');
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
